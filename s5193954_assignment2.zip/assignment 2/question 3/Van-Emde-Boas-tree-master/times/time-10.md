| Operation | vEB Tree | Set |  
| -------- | -------- | --- |  
 | INSERT | 0.012720 | 0.019445 |  
 | LOOKUP | 0.010971 | 0.015886 |  
 | PREDECESSOR | 0.023441 | 0.015866 |  
 | SUCCESSOR | 0.019809 | 0.015724 |  
 | ERASE | 0.005603 | 0.000672 |  
