| Operation | vEB Tree | Set |  
| -------- | -------- | --- |  
 | INSERT | 0.014786 | 0.036410 |  
 | LOOKUP | 0.012917 | 0.031506 |  
 | PREDECESSOR | 0.030551 | 0.031477 |  
 | SUCCESSOR | 0.024691 | 0.031468 |  
 | ERASE | 0.006963 | 0.000690 |  
