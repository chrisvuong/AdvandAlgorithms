#include<iostream>
#include<vector>
#include<string>
#include<fstream>
#include<algorithm>
#include<map>
#include<set>
#include<queue>
using namespace std;

#define dictionaryFile "./dictionary.txt"

set<string> getdictionary(int n = 0){
    ifstream file;
    set<string> rs;
    file.open(dictionaryFile);
    if(file.is_open()){
        string line;
        while ( getline (file,line) ){
            // line.erase(remove(line.begin(), line.end(), ' '), line.end());
            if(!n  || (n and line.size() == n))
                rs.insert(line);
        }
    } else 
        throw "Unable to open dictionary.txt" ;
    file.close();
    return rs;
}

struct Node{
    string value;
    int size = 0;
    Node *parent ;
    Node(string value): value(value), parent(NULL), size(1){};
    Node(string value, Node *parent): value(value), parent(parent){
        size = parent->size +1 ;
    };
};

Node getParent(Node child){
    return *child.parent;
}

void printNode(Node const *n){
    cout << n->size <<" ";
    while (n->parent != nullptr )
    {   cout << n->value <<" ";
        n = n->parent;
    }
    cout<< " " << n->value<<endl;
}

vector<string> circularSequenceBFS(string start, set<string> dict){
    int size = start.size();
    string standard = start.substr(1,2);
    

    map<string, vector<string> > graph;
    for(auto i : dict){
        string str = i.substr(1,2);
        graph[str].push_back(i);
        // if(i == "karat")
        //     cout<< str <<" "<< "baric"<<endl;
    }
    queue< Node* > qNode;
    Node *initRS = new Node(start);
    // initRS.push_back(start);
    qNode.push(initRS);
    map<string, int> visited;
    visited[start] = 1;
    vector<Node*> result;
    int maxsize = 0;
    while (!qNode.empty())
    {   
        Node *current = qNode.front();
        qNode.pop();
        string currentStr = current->value;
        // Node currentParent = *(current.parent);
        visited[currentStr] = 1;
        string substring = currentStr.substr(size-3,2);
        // cout<< "work "<< ++c;
        if(substring == standard && currentStr != start && current->size > maxsize){
            // cout<< current-> size<< endl;
            maxsize = current->size;
            printNode(current);
            result.push_back(current);
        } 
        
        for(auto str: graph[substring]){
            if (!visited[str]){
                Node *newChild = new Node(str, current);
                qNode.push(newChild);
            }
                
        }
    }
    Node *max = new Node("") ;
    for(auto rs: result)
        max = (max->size > rs->size) ? max: rs;
    // Node maxNode = *max;
    vector<string> maxReturn;
    cout<< max->size<< endl;
    
    return maxReturn;
    
}
void DFS(   Node *node, vector<Node *> results,
            map<string, vector<string> > const &graph, 
            map<string, int> &visited,
            string const &standard
        ){
    cout<< "err";
    string value = node->value;
    visited[value] = true;
    string subtring = value.substr(value.size()-3,2);
    if(subtring == standard)
        {
            results.push_back(node);
            return;    
        }
    for(auto str:graph.at(subtring)){
        if(!visited[str]){
            Node *newNode = new Node(value,node);
            DFS(newNode, results,graph,visited,standard);
        }
    }
    
}
void circularSequence(string start, set<string> dict){
    int size = start.size();
    string standard = start.substr(1,2);
    map<string, vector<string> > graph;
    for(auto i : dict){
        string str = i.substr(1,2);
        graph[str].push_back(i);
    }
    Node *initNode = new Node(start);
    vector<Node *> results;
    map<string, int> visited; 
    DFS(initNode, results, graph, visited, standard);
    cout<< results.size();

}

int main(){
    string word = "blare";
    int size = word.size();
    set<string> dict = getdictionary(size);
    vector<string> max;
    int i = 0;
    circularSequence(word,dict);
    // for(auto word: dict){
    //     vector<string> results = circularSequence(word,dict);
    //     // cout<< results.size()<<endl;
    //     // for(auto result: results){
    //     //     cout<< result << " ";
    //     // }
    //     cout<< ++i << " ";
    //     cout<< endl;
    //     max = max.size() > results.size()? max: results;
        
    // }
        

    cout<< max.size()<<endl;
    for(auto result: max){
        cout<< result << " ";
    }
    cout<< endl;
    
    return 0;
}

